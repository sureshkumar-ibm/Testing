package com.wm.sqs;

// webMethods IS service infrastructure
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataFactory;
import com.wm.data.IDataUtil;
import com.wm.app.b2b.server.ServiceException;

// AWS SDK v2
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.Message;
import software.amazon.awssdk.services.sqs.model.MessageAttributeValue;
import software.amazon.awssdk.services.sqs.model.ReceiveMessageRequest;
import software.amazon.awssdk.services.sqs.model.ReceiveMessageResponse;
import software.amazon.awssdk.services.sqs.model.SqsException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * webMethods Java Service: readFromSQS
 *
 * Reads messages from an Amazon SQS queue using pre-obtained short-lived
 * session credentials.  Call getTemporaryCredential first to obtain the
 * credentials, then pass them into this service.
 *
 * ─── Input pipeline variables ────────────────────────────────────────────────
 *  queueUrl           (String, required) Full SQS queue URL
 *  region             (String, required) AWS region, e.g. "us-east-1"
 *  awsAccessKeyId     (String, required) Temporary access key from getTemporaryCredential
 *  awsSecretAccessKey (String, required) Temporary secret key from getTemporaryCredential
 *  awsSessionToken    (String, required) Session token from getTemporaryCredential
 *  maxMessages        (String, optional) Number of messages to fetch: 1–10, default 1
 *  waitTimeSeconds    (String, optional) Long-poll wait time: 0–20 seconds, default 0
 *  visibilityTimeout  (String, optional) Seconds message stays invisible, default 30
 *
 * ─── Output pipeline variables ───────────────────────────────────────────────
 *  messages     (IData[], document list) Each entry contains:
 *                 messageId         (String)
 *                 receiptHandle     (String)  ← pass to deleteFromSQS
 *                 body              (String)
 *                 attributes        (IData)   system attributes
 *                 messageAttributes (IData)   custom attributes
 *  messageCount (String) total number of messages returned
 */
public final class SQSReadService {

    private SQSReadService() {}

    /**
     * Entry point called by webMethods IS runtime.
     * Uses pre-obtained session credentials passed in from the pipeline.
     */
    public static final void readFromSQS(IData pipeline) throws ServiceException {
        IDataCursor cursor = pipeline.getCursor();

        try {
            // ── Read inputs ──────────────────────────────────────────────────
            String queueUrl           = IDataUtil.getString(cursor, "queueUrl");
            String region             = IDataUtil.getString(cursor, "region");
            String awsAccessKeyId     = IDataUtil.getString(cursor, "awsAccessKeyId");
            String awsSecretAccessKey = IDataUtil.getString(cursor, "awsSecretAccessKey");
            String awsSessionToken    = IDataUtil.getString(cursor, "awsSessionToken");
            String maxMessagesStr     = IDataUtil.getString(cursor, "maxMessages");
            String waitTimeStr        = IDataUtil.getString(cursor, "waitTimeSeconds");
            String visibilityStr      = IDataUtil.getString(cursor, "visibilityTimeout");

            // ── Validate required inputs ─────────────────────────────────────
            ServiceUtil.validateRequired("queueUrl",           queueUrl);
            ServiceUtil.validateRequired("region",             region);
            ServiceUtil.validateRequired("awsAccessKeyId",     awsAccessKeyId);
            ServiceUtil.validateRequired("awsSecretAccessKey", awsSecretAccessKey);
            ServiceUtil.validateRequired("awsSessionToken",    awsSessionToken);

            // ── Apply defaults for optional inputs ───────────────────────────
            int maxMessages       = ServiceUtil.parseIntOrDefault(maxMessagesStr, 1);
            int waitTimeSeconds   = ServiceUtil.parseIntOrDefault(waitTimeStr, 0);
            int visibilityTimeout = ServiceUtil.parseIntOrDefault(visibilityStr, 30);

            // Clamp to SQS limits
            maxMessages     = Math.min(Math.max(maxMessages, 1), 10);
            waitTimeSeconds = Math.min(Math.max(waitTimeSeconds, 0), 20);

            // ── Build SQS client from pre-obtained session credentials ────────
            try (SqsClient sqsClient = ServiceUtil.buildSqsClient(
                    region, awsAccessKeyId, awsSecretAccessKey, awsSessionToken)) {

                ReceiveMessageRequest receiveRequest = ReceiveMessageRequest.builder()
                        .queueUrl(queueUrl)
                        .maxNumberOfMessages(maxMessages)
                        .waitTimeSeconds(waitTimeSeconds)
                        .visibilityTimeout(visibilityTimeout)
                        .attributeNamesWithStrings("All")
                        .messageAttributeNames("All")
                        .build();

                ReceiveMessageResponse response = sqsClient.receiveMessage(receiveRequest);
                List<Message> messages = response.messages();

                IDataUtil.put(cursor, "messages",     buildMessageDocuments(messages));
                IDataUtil.put(cursor, "messageCount", String.valueOf(messages.size()));
            }

        } catch (SqsException e) {
            throw new ServiceException(
                    "SQS error [" + e.awsErrorDetails().errorCode() + "]: "
                    + e.awsErrorDetails().errorMessage(), e);
        } catch (ServiceException e) {
            throw e;
        } catch (Exception e) {
            throw new ServiceException("readFromSQS failed: " + e.getMessage(), e);
        } finally {
            cursor.destroy();
        }
    }

    // -------------------------------------------------------------------------
    // Private helpers
    // -------------------------------------------------------------------------

    private static IData[] buildMessageDocuments(List<Message> messages) {
        List<IData> docs = new ArrayList<>(messages.size());
        for (Message msg : messages) {
            IData doc = IDataFactory.create();
            IDataCursor dc = doc.getCursor();
            IDataUtil.put(dc, "messageId",         msg.messageId());
            IDataUtil.put(dc, "receiptHandle",     msg.receiptHandle());
            IDataUtil.put(dc, "body",              msg.body());
            IDataUtil.put(dc, "attributes",        buildAttributesDocument(msg.attributesAsStrings()));
            IDataUtil.put(dc, "messageAttributes", buildMessageAttributesDocument(msg.messageAttributes()));
            dc.destroy();
            docs.add(doc);
        }
        return docs.toArray(new IData[0]);
    }

    private static IData buildAttributesDocument(Map<String, String> attrs) {
        IData doc = IDataFactory.create();
        if (attrs != null && !attrs.isEmpty()) {
            IDataCursor dc = doc.getCursor();
            for (Map.Entry<String, String> e : attrs.entrySet()) {
                IDataUtil.put(dc, e.getKey(), e.getValue());
            }
            dc.destroy();
        }
        return doc;
    }

    private static IData buildMessageAttributesDocument(Map<String, MessageAttributeValue> attrs) {
        IData doc = IDataFactory.create();
        if (attrs != null && !attrs.isEmpty()) {
            IDataCursor dc = doc.getCursor();
            for (Map.Entry<String, MessageAttributeValue> e : attrs.entrySet()) {
                MessageAttributeValue val = e.getValue();
                String strVal = val.stringValue() != null ? val.stringValue()
                        : (val.binaryValue() != null ? val.binaryValue().toString() : "");
                IDataUtil.put(dc, e.getKey(), strVal);
            }
            dc.destroy();
        }
        return doc;
    }

}
