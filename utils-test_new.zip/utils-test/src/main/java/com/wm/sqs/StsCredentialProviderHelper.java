package com.wm.sqs;

import software.amazon.awssdk.auth.credentials.AwsCredentials;
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
import software.amazon.awssdk.auth.credentials.AwsSessionCredentials;
import software.amazon.awssdk.core.exception.SdkClientException;
import software.amazon.awssdk.http.apache.ApacheHttpClient;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.rolesanywhere.RolesAnywhereClient;
import software.amazon.awssdk.services.rolesanywhere.model.CreateSessionRequest;
import software.amazon.awssdk.services.rolesanywhere.model.CreateSessionResponse;
import software.amazon.awssdk.services.rolesanywhere.model.CredentialSummary;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.KeyStore;
import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Helper that builds and caches credential providers per roleArn using
 * X.509 client certificates via AWS IAM Roles Anywhere.
 *
 * The client certificate and private key are loaded from a PKCS#12 (.p12/.pfx)
 * keystore and used to sign the CreateSession request with the
 * aws4-x509-rsa-sha256 scheme.  The call returns short-lived session
 * credentials (accessKeyId, secretAccessKey, sessionToken) — no long-lived
 * IAM keys are required anywhere in the code or configuration.
 *
 * Required IAM Roles Anywhere resources:
 *   - A Trust Anchor registered with the CA that issued the client certificate
 *   - A Profile that maps the certificate to the target IAM role
 *   - The IAM role must trust the Roles Anywhere service principal
 *
 * Required IAM permissions for the assumed role:
 *   - sqs:ReceiveMessage
 *   - sqs:DeleteMessage
 *   - sqs:GetQueueAttributes  (optional)
 */
public class StsCredentialProviderHelper {

    // Cache providers keyed by profileArn#roleArn#sessionName
    private static final ConcurrentHashMap<String, X509CredentialsProvider> CACHE =
            new ConcurrentHashMap<>();

    private StsCredentialProviderHelper() {}

    /**
     * Returns a cached (or newly created) {@link X509CredentialsProvider} that
     * obtains short-lived AWS credentials by presenting an X.509 client
     * certificate to the AWS IAM Roles Anywhere service.
     *
     * <p>The certificate and private key must be stored in a PKCS#12 keystore
     * file ({@code .p12} or {@code .pfx}).  The keystore is loaded once and
     * reused for every credential refresh.
     *
     * <p>Credentials are refreshed automatically when they approach expiry
     * (5 minutes before the reported expiration time).
     *
     * @param region           AWS region where the Roles Anywhere resources reside
     * @param trustAnchorArn   ARN of the Roles Anywhere Trust Anchor
     * @param profileArn       ARN of the Roles Anywhere Profile
     * @param roleArn          ARN of the IAM role to assume
     * @param roleSessionName  Identifier for this session (visible in CloudTrail)
     * @param tokenTtlSeconds  Requested session duration in seconds (900–3600)
     * @param keystorePath     Filesystem path to the PKCS#12 keystore file
     * @param keystorePassword Password for the PKCS#12 keystore
     * @return AwsCredentialsProvider backed by X.509-derived temp credentials
     */
    public static AwsCredentialsProvider getProvider(
            String region,
            String trustAnchorArn,
            String profileArn,
            String roleArn,
            String roleSessionName,
            int tokenTtlSeconds,
            String keystorePath,
            String keystorePassword) {

        String cacheKey = profileArn + "#" + roleArn + "#" + roleSessionName;

        return CACHE.computeIfAbsent(cacheKey, key -> new X509CredentialsProvider(
                region, trustAnchorArn, profileArn, roleArn,
                roleSessionName, tokenTtlSeconds,
                keystorePath, keystorePassword));
    }

    /**
     * Invalidates the cached provider for the given profile + role + session.
     * Call this if the certificate or keystore is rotated.
     */
    public static void invalidate(String profileArn, String roleArn, String roleSessionName) {
        String cacheKey = profileArn + "#" + roleArn + "#" + roleSessionName;
        CACHE.remove(cacheKey);
    }

    /**
     * Returns the ISO-8601 expiry timestamp of the currently cached credentials,
     * or {@code "UNKNOWN"} if no credentials have been fetched yet for this key.
     * Used by {@code CredentialService} to expose expiry in the pipeline.
     */
    public static String getExpiryForProvider(String profileArn, String roleArn, String roleSessionName) {
        String cacheKey = profileArn + "#" + roleArn + "#" + roleSessionName;
        X509CredentialsProvider provider = CACHE.get(cacheKey);
        if (provider == null || provider.expiresAt == null || provider.expiresAt.equals(Instant.EPOCH)) {
            return "UNKNOWN";
        }
        return provider.expiresAt.toString();
    }

    // =========================================================================
    // X.509 → Roles Anywhere CreateSession credential provider
    // =========================================================================

    /**
     * An {@link AwsCredentialsProvider} that calls the AWS IAM Roles Anywhere
     * {@code CreateSession} API using a mutual-TLS client certificate loaded
     * from a PKCS#12 keystore.  Credentials are lazily fetched on first use
     * and refreshed automatically when within 5 minutes of expiry.
     */
    static final class X509CredentialsProvider implements AwsCredentialsProvider {

        private static final Duration REFRESH_BUFFER = Duration.ofMinutes(5);

        private final String region;
        private final String trustAnchorArn;
        private final String profileArn;
        private final String roleArn;
        private final String roleSessionName;
        private final int tokenTtlSeconds;
        private final String keystorePath;
        private final String keystorePassword;

        private volatile AwsSessionCredentials cachedCredentials;
        private volatile Instant expiresAt = Instant.EPOCH;

        X509CredentialsProvider(
                String region,
                String trustAnchorArn,
                String profileArn,
                String roleArn,
                String roleSessionName,
                int tokenTtlSeconds,
                String keystorePath,
                String keystorePassword) {
            this.region           = region;
            this.trustAnchorArn   = trustAnchorArn;
            this.profileArn       = profileArn;
            this.roleArn          = roleArn;
            this.roleSessionName  = roleSessionName;
            this.tokenTtlSeconds  = tokenTtlSeconds;
            this.keystorePath     = keystorePath;
            this.keystorePassword = keystorePassword;
        }

        @Override
        public AwsCredentials resolveCredentials() {
            if (cachedCredentials == null ||
                    Instant.now().isAfter(expiresAt.minus(REFRESH_BUFFER))) {
                synchronized (this) {
                    if (cachedCredentials == null ||
                            Instant.now().isAfter(expiresAt.minus(REFRESH_BUFFER))) {
                        refresh();
                    }
                }
            }
            return cachedCredentials;
        }

        private void refresh() {
            try {
                char[] password = (keystorePassword != null) ? keystorePassword.toCharArray() : new char[0];

                // Load PKCS#12 keystore containing the client certificate + private key
                KeyStore keyStore = KeyStore.getInstance("PKCS12");
                try (InputStream ks = new FileInputStream(keystorePath)) {
                    keyStore.load(ks, password);
                }

                // KeyManagerFactory presents the client certificate during TLS handshake
                KeyManagerFactory kmf = KeyManagerFactory.getInstance(
                        KeyManagerFactory.getDefaultAlgorithm());
                kmf.init(keyStore, password);

                // TrustManagerFactory uses the JVM default trust store to verify AWS's cert
                TrustManagerFactory tmf = TrustManagerFactory.getInstance(
                        TrustManagerFactory.getDefaultAlgorithm());
                tmf.init((KeyStore) null);

                SSLContext sslContext = SSLContext.getInstance("TLS");
                sslContext.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

                // Apache HTTP client configured with the client certificate for mTLS
                ApacheHttpClient.Builder httpClient = ApacheHttpClient.builder()
                        .tlsKeyManagersProvider(kmf::getKeyManagers);

                // Roles Anywhere signs the request with aws4-x509-rsa-sha256;
                // no accessKeyId or secretAccessKey are needed here.
                try (RolesAnywhereClient rolesAnywhereClient = RolesAnywhereClient.builder()
                        .region(Region.of(region))
                        .httpClientBuilder(httpClient)
                        .build()) {

                    CreateSessionRequest req = CreateSessionRequest.builder()
                            .trustAnchorArn(trustAnchorArn)
                            .profileArn(profileArn)
                            .roleArn(roleArn)
                            .sessionName(roleSessionName)
                            .durationSeconds(tokenTtlSeconds)
                            .build();

                    CreateSessionResponse response = rolesAnywhereClient.createSession(req);

                    if (response.credentialSet() == null || response.credentialSet().isEmpty()) {
                        throw new IllegalStateException(
                                "IAM Roles Anywhere CreateSession returned no credentials.");
                    }

                    CredentialSummary cred = response.credentialSet().get(0).credentials();
                    cachedCredentials = AwsSessionCredentials.create(
                            cred.accessKeyId(),
                            cred.secretAccessKey(),
                            cred.sessionToken());

                    expiresAt = Instant.parse(cred.expiration());
                }

            } catch (Exception e) {
                throw SdkClientException.create(
                        "Failed to obtain temporary credentials via X.509 certificate: " + e.getMessage(), e);
            }
        }
    }
}
