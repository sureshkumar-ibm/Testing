package System_AWS;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataFactory;
import com.wm.data.IDataUtil;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.DeleteMessageRequest;
import software.amazon.awssdk.services.sqs.model.Message;
import software.amazon.awssdk.services.sqs.model.ReceiveMessageRequest;
import software.amazon.awssdk.services.sqs.model.ReceiveMessageResponse;
import software.amazon.rolesanywhere.plugin.RolesAnywherePlugin;
import software.amazon.rolesanywhere.plugin.X509Identity;
import software.amazon.rolesanywhere.plugin.X509IdentityProvider;
// --- <<IS-END-IMPORTS>> ---

public final class services

{
	// ---( internal utility methods )---

	final static services _instance = new services();

	static services _newInstance() { return new services(); }

	static services _cast(Object o) { return (services)o; }

	// ---( server methods )---




	public static final void awstest (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(awstest)>> ---
		// @sigtype java 3.5
		// [i] field:0:required keystoreAlias
		// [i] field:0:required keyAlias
		// [i] field:0:required trustAnchorArn
		// [i] field:0:required profileArn
		// [i] field:0:required roleArn
		// [i] field:0:required region
		// [i] field:0:required queueUrl
		// [i] field:0:required maxMessages
		// [i] field:0:required waitTimeSeconds
		// [i] field:0:required visibilityTimeout
		// [i] field:0:required deleteAfterRead
		// [i] field:0:required roleSessionName
		// [i] field:0:required durationSeconds
		// [o] field:0:required success
		// [o] field:0:required messageCount
		// [o] field:1:required messageIds
		// [o] field:1:required messageBodies
		// [o] field:1:required receiptHandles
		// [o] record:1:required messageAttributes
		// [o] field:1:required deletedMessageIds
		// [o] field:0:required errorMessage
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	keystoreAlias = IDataUtil.getString( pipelineCursor, "keystoreAlias" );
			String	keyAlias = IDataUtil.getString( pipelineCursor, "keyAlias" );
			String	trustAnchorArn = IDataUtil.getString( pipelineCursor, "trustAnchorArn" );
			String	profileArn = IDataUtil.getString( pipelineCursor, "profileArn" );
			String	roleArn = IDataUtil.getString( pipelineCursor, "roleArn" );
			String	region = IDataUtil.getString( pipelineCursor, "region" );
			String	queueUrl = IDataUtil.getString( pipelineCursor, "queueUrl" );
			String	maxMessages = IDataUtil.getString( pipelineCursor, "maxMessages" );
			String	waitTimeSeconds = IDataUtil.getString( pipelineCursor, "waitTimeSeconds" );
			String	visibilityTimeout = IDataUtil.getString( pipelineCursor, "visibilityTimeout" );
			String	deleteAfterRead = IDataUtil.getString( pipelineCursor, "deleteAfterRead" );
			String	roleSessionName = IDataUtil.getString( pipelineCursor, "roleSessionName" );
			String	durationSeconds = IDataUtil.getString( pipelineCursor, "durationSeconds" );
		pipelineCursor.destroy();
		
		// input
		IData input = IDataFactory.create();
		IDataCursor inputCursor = input.getCursor();
		IDataUtil.put( inputCursor, "keyStoreAlias", "keyStoreAlias" );
		IDataUtil.put( inputCursor, "keyAlias", "keyAlias" );
		inputCursor.destroy();
		
		// output
		IData 	output = IDataFactory.create();
		try{
			output = Service.doInvoke( "pub.security.keystore", "getKeyAndChain", input );
		}catch( Exception e){}
		IDataCursor outputCursor = output.getCursor();
			Object	privateKey = IDataUtil.get( outputCursor, "privateKey" );
			Object[]	certChainObjects = IDataUtil.getObjectArray( outputCursor, "certChain" );
		outputCursor.destroy();
		
		List<X509Certificate> intermediateCerts =
			    new ArrayList<X509Certificate>();
		
			X509Certificate leafCertificate = null;
		
			for (int i = 0; i < certChainObjects.length; i++) {
		
			    Certificate cert = (Certificate) certChainObjects[i];
		
			    if (!(cert instanceof X509Certificate)) {
			        continue;
			    }
		
			    if (i == 0) {
			        leafCertificate = (X509Certificate) cert;
			    } else {
			        intermediateCerts.add((X509Certificate) cert);
			    }
			}
		
			if (leafCertificate == null) {
			    throw new ServiceException(
			        "Leaf certificate not found in certChain");
			}
		
			
			X509Identity identity =
				    X509Identity.createWithoutDestroyingKey(
				        leafCertificate,
				        (PrivateKey) privateKey,
				        intermediateCerts);
		
				X509IdentityProvider identityProvider =
				    X509IdentityProvider.ofStatic(identity);
				
			    RolesAnywherePlugin plugin =
			            RolesAnywherePlugin.builder()
			                .identityProvider(identityProvider)
			                .trustAnchorArn(trustAnchorArn)
			                .profileArn(profileArn)
			                .roleArn(roleArn)
			                .roleSessionName(roleSessionName)
			                .durationSeconds(Integer.parseInt(durationSeconds))
			                .region(Region.of(region))
			                .build();		
			    SqsClient sqsClient = null;
			    sqsClient =
			            SqsClient.builder()
			                .region(Region.of(region))
			                .addPlugin(plugin)
			                .build();
			    ReceiveMessageRequest.Builder receiveRequestBuilder =
			            ReceiveMessageRequest.builder()
			                .queueUrl(queueUrl)
			                .maxNumberOfMessages(Integer.parseInt(maxMessages))
			                .waitTimeSeconds(Integer.parseInt(waitTimeSeconds))
			                .messageAttributeNames("All")
			                .attributeNamesWithStrings("All");
		
			        if (visibilityTimeout != null) {
			            receiveRequestBuilder.visibilityTimeout(
			                visibilityTimeout.intValue()
			            );
			        }
		
			        ReceiveMessageResponse receiveResponse =
			            sqsClient.receiveMessage(
			                receiveRequestBuilder.build()
			            );
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "success", "success" );
		IDataUtil.put( pipelineCursor_1, "messageCount", "messageCount" );
		String[]	messageIds = new String[1];
		messageIds[0] = "messageIds";
		IDataUtil.put( pipelineCursor_1, "messageIds", messageIds );
		String[]	messageBodies = new String[1];
		messageBodies[0] = "messageBodies";
		IDataUtil.put( pipelineCursor_1, "messageBodies", messageBodies );
		String[]	receiptHandles = new String[1];
		receiptHandles[0] = "receiptHandles";
		IDataUtil.put( pipelineCursor_1, "receiptHandles", receiptHandles );
		
		// messageAttributes
		IData[]	messageAttributes = new IData[1];
		messageAttributes[0] = IDataFactory.create();
		IDataUtil.put( pipelineCursor_1, "messageAttributes", messageAttributes );
		String[]	deletedMessageIds = new String[1];
		deletedMessageIds[0] = "deletedMessageIds";
		IDataUtil.put( pipelineCursor_1, "deletedMessageIds", deletedMessageIds );
		IDataUtil.put( pipelineCursor_1, "errorMessage", "errorMessage" );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}
}

