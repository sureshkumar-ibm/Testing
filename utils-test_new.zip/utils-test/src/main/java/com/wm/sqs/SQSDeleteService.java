package com.wm.sqs;

// webMethods IS service infrastructure
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataUtil;
import com.wm.app.b2b.server.ServiceException;

// AWS SDK v2
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.DeleteMessageRequest;
import software.amazon.awssdk.services.sqs.model.SqsException;

/**
 * webMethods Java Service: deleteFromSQS
 *
 * Deletes a single message from an Amazon SQS queue using pre-obtained
 * short-lived session credentials.  Call getTemporaryCredential first to
 * obtain the credentials, then pass them into this service.
 *
 * The receiptHandle is returned by readFromSQS in the messages[] array.
 *
 * ─── Input pipeline variables ────────────────────────────────────────────────
 *  queueUrl           (String, required) Full SQS queue URL
 *  receiptHandle      (String, required) Receipt handle from readFromSQS output
 *  region             (String, required) AWS region, e.g. "us-east-1"
 *  awsAccessKeyId     (String, required) Temporary access key from getTemporaryCredential
 *  awsSecretAccessKey (String, required) Temporary secret key from getTemporaryCredential
 *  awsSessionToken    (String, required) Session token from getTemporaryCredential
 *
 * ─── Output pipeline variables ───────────────────────────────────────────────
 *  deleteStatus  (String) "SUCCESS" on successful deletion
 *  receiptHandle (String) Echo of the deleted message's receipt handle
 */
public final class SQSDeleteService {

    private SQSDeleteService() {}

    /**
     * Entry point called by webMethods IS runtime.
     * Uses pre-obtained session credentials passed in from the pipeline.
     */
    public static final void deleteFromSQS(IData pipeline) throws ServiceException {
        IDataCursor cursor = pipeline.getCursor();

        try {
            // ── Read inputs ──────────────────────────────────────────────────
            String queueUrl           = IDataUtil.getString(cursor, "queueUrl");
            String receiptHandle      = IDataUtil.getString(cursor, "receiptHandle");
            String region             = IDataUtil.getString(cursor, "region");
            String awsAccessKeyId     = IDataUtil.getString(cursor, "awsAccessKeyId");
            String awsSecretAccessKey = IDataUtil.getString(cursor, "awsSecretAccessKey");
            String awsSessionToken    = IDataUtil.getString(cursor, "awsSessionToken");

            // ── Validate required inputs ─────────────────────────────────────
            ServiceUtil.validateRequired("queueUrl",           queueUrl);
            ServiceUtil.validateRequired("receiptHandle",      receiptHandle);
            ServiceUtil.validateRequired("region",             region);
            ServiceUtil.validateRequired("awsAccessKeyId",     awsAccessKeyId);
            ServiceUtil.validateRequired("awsSecretAccessKey", awsSecretAccessKey);
            ServiceUtil.validateRequired("awsSessionToken",    awsSessionToken);

            // ── Build SQS client from pre-obtained session credentials ────────
            try (SqsClient sqsClient = ServiceUtil.buildSqsClient(
                    region, awsAccessKeyId, awsSecretAccessKey, awsSessionToken)) {

                sqsClient.deleteMessage(DeleteMessageRequest.builder()
                        .queueUrl(queueUrl)
                        .receiptHandle(receiptHandle)
                        .build());

                IDataUtil.put(cursor, "deleteStatus",  "SUCCESS");
                IDataUtil.put(cursor, "receiptHandle", receiptHandle);
            }

        } catch (SqsException e) {
            throw new ServiceException(
                    "SQS error [" + e.awsErrorDetails().errorCode() + "]: "
                    + e.awsErrorDetails().errorMessage(), e);
        } catch (ServiceException e) {
            throw e;
        } catch (Exception e) {
            throw new ServiceException("deleteFromSQS failed: " + e.getMessage(), e);
        } finally {
            cursor.destroy();
        }
    }

}
